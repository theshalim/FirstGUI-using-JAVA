
package firstgui;
import javax.swing.*;
public class FirstGUI {

    public static void main(String[] args) {
        JFrame jframe = new JFrame("First GUI");
        JPanel jpane = new JPanel();
        JButton jbutton = new JButton("Try Now");
        
        jframe.setContentPane(jpane);
        jpane.add(jbutton);
        
        jframe.setSize(300, 250);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jframe.setVisible(true);
    }
    
}
